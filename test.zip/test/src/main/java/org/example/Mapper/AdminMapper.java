package org.example.Mapper;

import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.example.Empties.Admin;
import org.example.Empties.Student;

import java.util.List;
import java.util.Map;

public interface AdminMapper {
    Admin AdminLogin(@Param("admin_id") String admin_id,@Param("admin_password") String admin_password);
    List<Student> SelectAll();
    @MapKey("student_id")
    Map<String,String>SimpleSelect();
    Student SelectById(int student_id);
    List<Student> SelectByGender(String gender);
    void AddStudent(Student student);
    void UpdateStudent(Student student);
    void DeleteById(int student_id);
    void DelectByIds(@Param("student_ids")int[] student_id);
}
