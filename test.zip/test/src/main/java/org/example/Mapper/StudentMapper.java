package org.example.Mapper;

import org.apache.ibatis.annotations.Param;
import org.example.Empties.Student;

public interface StudentMapper {
    //1:根据账号密码来找(人)对象
    Student StudentLogin(@Param("student_id") String student_id, @Param("student_password") String student_password);

    void UpdateStudent(Student student);





}
