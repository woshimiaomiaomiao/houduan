package org.example.Empties;

public class Student {
    private int student_id;
    private String student_password;
    private String student_name;
    private String gender;
    private String college_class;
    private int period;
    private String direction;
    private String award_experience;

    public Student(int student_id, String student_password, String student_name) {
        this.student_id = student_id;
        this.student_password = student_password;
        this.student_name = student_name;
    }


    public Student(int student_id, String student_password, String student_name, String gender, String college_class, int period, String direction, String award_experience) {
        this.student_id = student_id;
        this.student_password = student_password;
        this.student_name = student_name;
        this.gender = gender;
        this.college_class = college_class;
        this.period = period;
        this.direction = direction;
        this.award_experience = award_experience;
    }

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public String getStudent_password() {
        return student_password;
    }

    public void setStudent_password(String student_password) {
        this.student_password = student_password;
    }

    public String getStudent_name() {
        return student_name;
    }

    public void setStudent_name(String student_name) {
        this.student_name = student_name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCollege_class() {
        return college_class;
    }

    public void setCollege_class(String college_class) {
        this.college_class = college_class;
    }

    public int getPeriod() {
        return period;
    }

    public void setPeriod(int period) {
        this.period = period;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getAward_experience() {
        return award_experience;
    }

    public void setAward_experience(String award_experience) {
        this.award_experience = award_experience;
    }

    @Override
    public String toString() {
        return "Student{" +
                "student_id=" + student_id +
                ", student_password='" + student_password + '\'' +
                ", student_name='" + student_name + '\'' +
                ", gender='" + gender + '\'' +
                ", college_class='" + college_class + '\'' +
                ", period=" + period +
                ", direction='" + direction + '\'' +
                ", award_experience='" + award_experience + '\'' +
                '}';
    }
}
