package org.example.Empties;

public class Admin {
    private int admin_id;
    private String admin_password;
    private String admin_name;
    private String gender;

    public Admin(int admin_id, String admin_password, String admin_name, String gender) {
        this.admin_id = admin_id;
        this.admin_password = admin_password;
        this.admin_name = admin_name;
        this.gender = gender;
    }

    public int getAdmin_id() {
        return admin_id;
    }

    public void setAdmin_id(int admin_id) {
        this.admin_id = admin_id;
    }

    public String getAdmin_password() {
        return admin_password;
    }

    public void setAdmin_password(String admin_password) {
        this.admin_password = admin_password;
    }

    public String getAdmin_name() {
        return admin_name;
    }

    public void setAdmin_name(String admin_name) {
        this.admin_name = admin_name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
