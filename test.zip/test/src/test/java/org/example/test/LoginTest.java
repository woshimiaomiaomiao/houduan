package org.example.test;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.example.Empties.Admin;
import org.example.Empties.Student;
import org.example.Mapper.AdminMapper;
import org.example.Mapper.StudentMapper;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

public class LoginTest {
    @Test
    public void LoginTest() throws IOException {

        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession=sqlSessionFactory.openSession();
        AdminMapper adminMapper=sqlSession.getMapper(AdminMapper.class);
        Student student=new Student(2,"999","999");
        adminMapper.AddStudent(student);
        sqlSession.commit();

    }
}
